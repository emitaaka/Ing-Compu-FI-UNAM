letras = ('A', 'B', 'C', 'D', 'E', 'F')

# Convertir parte entera a base 10
def entDec(num, base):
    total = 0
    alreves = num[::-1]
    for i in range(len(num)):
        total += int(alreves[i]) * base**i
    return total

# Convertir parte decimal (después del punto) a base 10
def decDiez(num, base):
    total = 0
    for i in range(len(num)):
        potencia = -(i + 1)
        total += int(num[i]) * base**potencia
    return total

# Convierte cualquier letra de letras en un valor decimal
def letrasANumeros(letra):
    if letra in letra:
        return letras.index(letra) + 10
    else:
        return -1

# Convierte cualquier número en letra
def numerosALetras(numero):
    if numero - 1 < 37:
        return letras[numero - 10]
    else: 
        print("Error de rango.")

# Convierte cualquier número entero decimal a cualquier base
def decEnteroACualquier(num, base):
    valor = ""
    while num > 0:
        residuo = num % base
        num = num // base
        if residuo > 9:
            valor += numerosALetras(residuo)
        else:
            valor += str(residuo)
    return valor[::-1]

# Convierte cualquier número fraccionario decimal a cualquier base
def decFraccionACualquier(frac_str, base):
    num = int(frac_str) / 10 ** len(frac_str) if frac_str else 0.0
    valor = ""
    cont = 0
    while cont < 5:
        if num >= 1:
            num = (num % 1) * base
        else: 
            num = num * base
        ent = int(num // 1)
        if ent > 9:
            valor += numerosALetras(ent)
        else:
            valor += str(ent)
        cont += 1
    return valor

def sumar_un_bit(bit_a, bit_b, acarreo_in):
    suma_total = bit_a + bit_b + acarreo_in
    suma = suma_total % 2
    acarreo_out = 1 if suma_total >= 2 else 0
    return suma, acarreo_out

def a_complemento_2_6bits(n):
    if n == -32:
        return [1, 0, 0, 0, 0, 0]
    elif n < 0:
        magnitud = abs(n)
        mag_bin = list(map(int, format(magnitud, '05b')))
        
        invertido = [1 if bit == 0 else 0 for bit in mag_bin]
        
        acarreo = 1
        for i in range(4, -1, -1):
            suma_bit = invertido[i] + acarreo
            invertido[i] = suma_bit % 2
            acarreo = 1 if suma_bit >= 2 else 0
            
        return [1] + invertido
    else:
        return [0] + list(map(int, format(n, '05b')))

def sumar_binarios_6bits():
    print("Suma de números con signo de 6 bits (Rango: -32 a 31)")
    
    while True:
        try:
            num1 = int(input("Ingresa el primer número decimal (-32 a 31): "))
            num2 = int(input("Ingresa el segundo número decimal (-32 a 31): "))
            if -32 <= num1 <= 31 and -32 <= num2 <= 31:
                break
            print("Error: Los números deben estar entre -32 y 31.")
        except ValueError:
            print("Error: Ingresa números enteros válidos.")

    b6_1 = a_complemento_2_6bits(num1)
    b6_2 = a_complemento_2_6bits(num2)

    print(f"\nBinario 1 (C2): {''.join(map(str, b6_1))}")
    print(f"Binario 2 (C2): {''.join(map(str, b6_2))}")

    acarreo = 0
    suma_magnitud = [0] * 5
    for i in range(4, -1, -1):
        idx = i + 1 
        bit_s, acarreo = sumar_un_bit(b6_1[idx], b6_2[idx], acarreo)
        suma_magnitud[i] = bit_s

    acarreo_in_signo = acarreo
    bit_signo_final, acarreo_out_signo = sumar_un_bit(b6_1[0], b6_2[0], acarreo_in_signo)

    resultado_bits = [bit_signo_final] + suma_magnitud
    resultado_str = ''.join(map(str, resultado_bits))

    overflow = (acarreo_in_signo != acarreo_out_signo)

    print(f"Resultado binario (6 bits): {resultado_str}")
    
    if resultado_bits[0] == 1:
        inv = [0 if b == 1 else 1 for b in resultado_bits[1:]]
        acarreo_dec = 1
        for i in range(4, -1, -1):
            s = inv[i] + acarreo_dec
            inv[i] = s % 2
            acarreo_dec = 1 if s >= 2 else 0
        val_mag = int(''.join(map(str, inv)), 2)
        dec_res = -val_mag
    else:
        dec_res = int(''.join(map(str, resultado_bits[1:])), 2)

    print(f"Resultado en decimal: {dec_res}")
    if overflow:
        print("Se ha detectado desbordamiento aritmético (Overflow)")
    else:
        print("Suma realizada sin desbordamiento.")

opc = 0

while opc != 3:
    # Menu
    print("\nBienvenido al conversor de bases, ¿qué deseas hacer?")
    print("1. Convertir un número de cualquier base a cualquier base.")
    print("2. Sumar (con Complemento a 2).")
    print("3. Salir")
    opc = int(input())

    if opc == 1:
        print(f'\nElegiste la opción {opc}: Convertir números.')
        
        # Validamos la base origen
        while True:
            try:
                baseOri = int(input("Ingresa la base de origen (2-16): "))
                if 2 <= baseOri <= 16:
                    break
                print("Error: La base debe estar entre 2 y 16.")
            except ValueError:
                print("Error: Ingresa un número entero válido.")

        # Validamos la base final
        while True:                
            try:
                baseConv = int(input("Ingresa la base a la que quieres convertir el número (2-16): "))
                if 2 <= baseConv <= 16:
                    break
                print("Error: La base de destino debe estar entre 2 y 16")
            except ValueError:
                print("Ingresa un númeor entero válido")

        entero = ""
        decimal = ""
        total = ""

        numAConv = input("Ingresa el numero a convertir: ")

        # Validamos que el número ingresado sea válido en la base origen
        valido = True

        # Rechazamos de entrada si hay más de un punto decimal
        if numAConv.count('.') > 1:
            print("El número no puede tener más de un punto decimal.")
            continue

        nuevoNumAConv = list(numAConv)
        for i in range(len(numAConv)):

            if numAConv[i] == '.':
                continue
            caracter = numAConv[i].upper()

            # Validamos que las letras sean válidas
            if caracter in letras:
                digito_val = letrasANumeros(caracter)
            elif caracter.isdigit():
                digito_val = int(caracter)
            else:
                print(f'{caracter} no es un dígito válido.')
                valido = False
                break
            
            # Validamos cara caracter
            if digito_val > baseOri - 1:
                print(f"{caracter} excede los límites de la base {baseOri}.")
                valido = False
                break
            
            nuevoNumAConv[i] = digito_val

        if not valido:
            continue

        entero = ""
        decimal = ""
        total = ""

        # Buscamos si hay punto en número, si lo hay, lo dividimos en 2 cadenas; una con la parte entera y otra con la parte fraccionaria
        posPunto = numAConv.find('.')
        if posPunto != -1:
            entero = nuevoNumAConv[:posPunto]
            decimal = nuevoNumAConv[posPunto + 1:]
            total += str(entDec(entero, baseOri) + decDiez(decimal, baseOri))
        else:
            entero = nuevoNumAConv
            total += str(entDec(entero, baseOri))

        #Si la base final es 10, imprimimos el resultado, si no, volvemos a dividir el número (si tiene parte fraccionaria) y lo convertimos a la base final
        if baseConv == 10:
            print(f"El numero {numAConv} convertido a base 10 es: {total}")
        else:
            posPunto2 = total.find(".")
            aConv = total
            if posPunto2 != -1:
                entero = int(aConv[:posPunto2])
                decimal = aConv[posPunto2 + 1:]
                total = str(decEnteroACualquier(entero, baseConv)) + '.' + (decFraccionACualquier(decimal, baseConv))
                print(f'El número {numAConv} convertido a base {baseConv} es: {total}')
            else:
                entero = int(aConv)
                total = decEnteroACualquier(entero, baseConv)
                print(f'El número {numAConv} convertido a base {baseConv} es: {total}')

    elif opc == 2:
        sumar_binarios_6bits()

    elif opc == 3:
        print("¡Adiós!")
    else:
        print("Ingresa un número válido por favor")